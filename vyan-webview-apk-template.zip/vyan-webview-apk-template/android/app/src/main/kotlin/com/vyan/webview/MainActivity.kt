package com.vyan.webview

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
