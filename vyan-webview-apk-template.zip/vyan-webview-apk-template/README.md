# Vyan Web to APK - Flutter WebView Template

Template Flutter untuk mengubah file ZIP (HTML/CSS/JS) menjadi APK Android offline.

## Cara Pakai

1. Upload repository ini ke GitHub
2. Setup GitHub Actions (sudah ada di `.github/workflows/build_apk.yml`)
3. Hubungkan dengan backend Vyan Web to APK

## Struktur

- `assets/www/` → folder yang akan diganti isi ZIP user
- `lib/main.dart` → WebView offline menggunakan flutter_inappwebview
- `.github/workflows/build_apk.yml` → otomatis build APK

Dibuat untuk project **Vyan Web to APK**.
